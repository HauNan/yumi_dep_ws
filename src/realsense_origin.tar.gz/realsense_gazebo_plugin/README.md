# Intel RealSense Gazebo ROS plugin

This package is a Gazebo ROS plugin for the Intel D435 realsense camera. 

This package has been tested on ROS kinetic on ubuntu 16.04 with Gazebo 7.
 
## Load in URDF

[Realsense D435 URDF](https://github.com/neocobot-nac/neocobot_robot/tree/v1.x.x/neo_description/urdf/Sensor/D435)

## Acknowledgement

This is a modified and updated version of work done by [SyrianSpock](https://github.com/SyrianSpock) and [pal-robotics](https://github.com/pal-robotics).


