
"use strict";

let YumiGrasp = require('./YumiGrasp.js')

module.exports = {
  YumiGrasp: YumiGrasp,
};
