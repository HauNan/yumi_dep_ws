^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package vision_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2017-11-14)
------------------
* Initial commit
* Contributors: Adam Allevato, Martin Gunther, procopiostein
