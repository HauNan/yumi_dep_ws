^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package aruco_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2019-09-27)
------------------
* Merge branch 'indigo-devel' into kinetic-devel
* Contributors: Victor Lopez

2.1.1 (2020-09-17)
------------------

2.1.0 (2020-01-21)
------------------

2.0.2 (2019-11-09)
------------------

2.0.1 (2019-09-27)
------------------

0.2.2 (2017-07-25)
------------------

0.2.1 (2017-07-21)
------------------

0.2.0 (2016-10-19)
------------------

0.1.0 (2015-08-10)
------------------
* Update changelogs and maintainer email
* Contributors: Bence Magyar

0.0.1 (2015-05-20)
------------------
* Reorganize aruco_ros into 3 packages
* Contributors: Bence Magyar
