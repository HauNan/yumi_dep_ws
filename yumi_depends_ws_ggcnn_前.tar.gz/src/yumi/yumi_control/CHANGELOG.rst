^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package yumi_control
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.4 (2017-01-12)
------------------

0.0.2 (2017-01-10)
------------------
* config files for joint trajectory controllers
* Contributors: Robert Krug, Todor Stoyanov
