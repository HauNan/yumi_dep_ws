The joint numbering for each arm follows ABB's strange convention, namely (in physical order starting with the joint connecting to the body): 1, 2, 7, 3, 4, 5, 6
